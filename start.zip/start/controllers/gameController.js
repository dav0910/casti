const Model = require('../models/gameModel');

function get_turno(){
    turn = Model.get_turno();
    if(turn === undefined){
        return "null"
    }
    return turn;
}

function add_giocatore(uuid){
    console.log("2");
    res = Model.add_giocatore(uuid);
    if(res === -1){
        return -1;
    }
    else{
        return 0;
    }
}

function rimuovi_giocatore(uuid){
    Model.rimuovi_giocatore(uuid);
}

function cambia_turno(uuid){
    res = Model.cambia_turno(uuid);
    return res;
}

function get_stato(){
    json = '{ "turn": "' + get_turno() + '",\n'
    json = json + '"gameboard": ' + Model.get_gameboard() + ",\n"
    json = json + '"vittorioso": '+ Model.get_vittorioso() + "\n}"
    return json;
}

function update_gameboard(pos, player){
    Model.update_gameboard(pos, player)
}

module.exports ={
    cambia_turno,
    get_turno,
    add_giocatore,
    rimuovi_giocatore,
    get_stato,
    update_gameboard
}