const http = require('http');
var fs = require("fs");
var url = require('url');


const Controller = require('./controllers/gameController.js');

const server = http.createServer((req, res) => {
  if (req.url === '/game' && req.method === 'GET'){
      fs.readFile(__dirname + '/client.html', function(error, data) {
        console.log("ciaoo " + __dirname + '/game.html')
        if (error) {
          res.writeHead(404);
          res.write(error);
          res.end();
        } else {
          res.writeHead(200, {'Content-Type':'text/html'});
          res.write(data);
          res.end();
        }
    });

  }
  if (req.url == '/api' && req.method === 'GET') {
    res.writeHead(200, {'Content-Type':'text/html'});
    res.write("hello from server");
    res.end();
  }
  if(req.url.split("?")[0] === '/api/add_giocatore' && req.method === 'GET')  {
    var url_parts = url.parse(req.url, true);
    var query = url_parts.query
    console.log(query.player);
    
    player_uuid = query.player;
    console.log("1");
    res_val = Controller.add_giocatore(player_uuid);
    res.writeHead(200, {'Content-Type':'text/html'});
    if(res_val == 0){
        res.write("1")
    }
    else{
        res.write("-1");
    }
    res.end();
  }

  if(req.url.split("?")[0] === '/api/get_turno' && req.method === 'GET')  {

    res_val = Controller.get_turno();
    res.writeHead(200, {'Content-Type':'text/html'});
    //console.log(res_val);
    res.write(res_val);
    res.end();
  }

  if(req.url.split("?")[0] === '/api/get_stato' && req.method === 'GET')  {

    res_val = Controller.get_stato();
    res.writeHead(200, {'Content-Type':'text/html'});
    res.write(res_val);
    res.end();
  }

  if(req.url.split("?")[0] === '/api/cambia_turno' && req.method === 'GET')  {
      var url_parts = url.parse(req.url, true);
      var query = url_parts.query
      player_UUID = query.player;
      console.log(query.player + " cambia turno");
      
    res_val = Controller.cambia_turno(player_UUID)
    res.writeHead(200, {'Content-Type':'text/html'});
    if(res_val == 0){
        res.write("true")
    }
    else{
        res.write("false");
    }
    res.end();
  }
  if(req.url.split("?")[0] === '/api/update_gameboard' && req.method === 'GET')  {
    var url_parts = url.parse(req.url, true);
    var query = url_parts.query
    player_UUID = query.player;
    pos = query.pos;
    console.log(query.player + " aggiorna pos: " + pos);
    if(Controller.get_turno == player_UUID){
        res_val = Controller.update_gameboard(pos,player_UUID)
        
        res.writeHead(200, {'Content-Type':'text/html'});
        if(res_val == 0){
            res.write('["result" : "true"')
            Controller.cambia_turno();
        }
        else{
          res.write('["result" : "false"')
        }
        res.end();
    }
    else{
      res.writeHead(200, {'Content-Type':'text/html'});
      res.write('["result" : "false"');
      res.end();
    }

}
  if(req.url.split("?")[0] === '/api/rimuovi_giocatore' && req.method === 'GET')  {

    var url_parts = url.parse(req.url, true);
    var query = url_parts.query
    player_UUID = query.player;
    console.log(query.player + " esce");

    res_val = Controller.rimuovi_giocatore(player_UUID)
    res.writeHead(200, {'Content-Type':'text/html'});
    if(res_val == 0){
        res.write("true")
    }
    else{
        res.write("false");
    }
    res.end();
  }

  

});

const PORT = process.env.PORT || 5000;

server.listen(PORT, () => console.log(`Server running on port ${PORT}`));

module.exports = server;