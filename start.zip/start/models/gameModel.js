//turno = ""; //UUID del computer a cui tocca

let giocatori = []; //lista degli UUID
let gameboard = [["0","0","0"],["0","0","0"],["0","0","0"]];
let vittorioso = "0";
function cambia_turno(uuid){


    if(uuid == giocatori[0]){
        console.log("Granted");
        giocatori.push(giocatori[0])
        giocatori.splice(0,1);
        return 0;
    }
    else{
        console.log("Rejected");
        console.log(giocatori)
        console.log(uuid)
        console.log(giocatori[0])
        return -1;
    }
}

function get_turno(){
    //console.log(giocatori[0])
    return giocatori[0];
}

function get_vittorioso(){
    return vittorioso;
}
function add_giocatore(uuid){
    console.log("3");
    if(giocatori.length >= 2){
        return -1;
    }
    giocatori.push(uuid);
    console.log(giocatori);
    return 0;
}

function get_giocatore(pos){
    try{
        return giocatori[pos]
    }
    catch{
        return -1;
    }
}
       
function rimuovi_giocatore(uuid){
    for(i = 0; i<giocatori.length;i++){
        if(giocatori[i] == uuid){
            giocatori.splice(i,1);
            return 0;
        }
    }
    return -1;
}

function update_gameboard(pos, player){
    if(gameboard[pos.substring(1)][pos.substring(1,2)] == ""){
        gameboard[pos.substring(1)][pos.substring(1,2)] = player;
        return 0;
    }
    vittorioso = vittoria()
    return 1;
}
function get_gameboard(){
    //console.log("[" + gameboard.toString() + "]");
    return "[" + gameboard.toString() + "]";
}

function vittoria() {
    for(let i=0; i<3; i++){

        if(gameboard[i][0] == gameboard[i][1] == gameboard[i][2]){
            return gameboard[i][0];
        }
    }
   
    for(let i=0; i<3; i++){

        if(gameboard[0][i] == gameboard[1][i] == gameboard[2][i]){
            return gameboard[0][i];
        }
    }
   
    if(gameboard[0][0] == gameboard[1][1] == gameboard[2][2]){
        return gameboard[0][0];
    }

    if(gameboard[0][2] == gameboard[1][1] == gameboard[2][0]){
        return gameboard[0][2];
    }
    
    return "0";
}



module.exports ={
    cambia_turno,
    get_turno,
    add_giocatore,
    get_giocatore,
    rimuovi_giocatore,
    get_gameboard,
    update_gameboard,
    get_vittorioso
}